# IDEF0 Diagrammer — v0.3.3b

Baseline rollback with hard orthogonal routing and sticky stubs.

- Open `index.html` in a browser.
- Click a handle, press **S** to add a stub.
- Double-click a connector/stub label to edit (or pick from the dropdown).
- Save/Load uses localStorage. Export JSON & SVG are built-in.

Files: `index.html`, `styles.css`, `app.js`, `sample_models.json`, `schema_patch.sql`, `streamlit_idef0_page.py`.
